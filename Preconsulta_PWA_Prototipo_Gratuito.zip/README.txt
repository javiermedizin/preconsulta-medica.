PRECONSULTA MÉDICA - PROTOTIPO PWA
Dr. Javier Navarro

CONTENIDO
- index.html: aplicación web.
- manifest.webmanifest: instalación como PWA.
- sw.js: caché para uso sin conexión después de la primera carga.
- icon.svg: icono.

PRUEBA LOCAL
Abrir index.html en un navegador permite revisar el formulario, pero las funciones PWA/offline requieren servirlo mediante HTTPS o localhost.

PUBLICACIÓN GRATUITA
1. Crear un repositorio público en GitHub.
2. Subir todos estos archivos a la raíz del repositorio.
3. En Settings > Pages, seleccionar Deploy from a branch, branch main, folder /(root).
4. GitHub Pages generará un enlace HTTPS.
5. Abrir el enlace en Safari/Chrome y probarlo antes de distribuirlo.

PRIVACIDAD Y LIMITACIONES
- Las respuestas se guardan en localStorage del navegador del dispositivo.
- El formulario genera un archivo JSON para compartir o descargar.
- No hay envío automático al consultorio ni conexión a Excel.
- El archivo JSON contiene información clínica en texto legible: no enviarlo por redes abiertas sin una política de seguridad apropiada. Para uso real se recomienda cifrado y canal de entrega evaluado.
- WhatsApp Business se abre/usa manualmente para adjuntar el archivo.
- No está certificado HIPAA ni constituye por sí solo una solución de expediente clínico.
- La caché offline no cifra el contenido.
- El prefijo se muestra a partir de una tabla de códigos telefónicos; algunos territorios comparten prefijo o requieren una selección más específica.
